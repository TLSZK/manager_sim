<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class Manager extends Model
{
    use HasUuids; // Critical for UUID support
    protected $fillable = ['name'];
    protected $with = ['history']; // Auto-include history in fetch

    public function history()
    {
        return $this->hasMany(ManagerHistory::class)->latest();
    }
}
