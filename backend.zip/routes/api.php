<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

use App\Http\Controllers\TeamController;
use App\Http\Controllers\ManagerController;
use App\Http\Controllers\SavedGameController;

Route::get('/teams', [TeamController::class, 'index']);

Route::prefix('managers')->group(function () {
    Route::get('/', [ManagerController::class, 'index']);
    Route::post('/', [ManagerController::class, 'store']);
    Route::put('/{id}', [ManagerController::class, 'update']);
    Route::delete('/{id}', [ManagerController::class, 'destroy']);
    Route::post('/{id}/history', [ManagerController::class, 'addHistory']);
    Route::get('/{id}/save', [SavedGameController::class, 'show']);
    Route::post('/{id}/save', [SavedGameController::class, 'store']);
});
