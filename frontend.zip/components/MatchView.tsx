
import React, { useEffect, useRef, useState } from 'react';
import { Team, Player } from '../types';
import { FORMATIONS, LIGA_LOGO_URL, UCL_LOGO_URL } from '../constants';
import { User, FastForward, Activity, List } from 'lucide-react';

interface MatchViewProps {
  homeTeam: Team;
  awayTeam: Team;
  userTeamId: string;
  onMatchComplete: (homeScore: number, awayScore: number) => void;
  competition?: string;
  stage?: string;
}

// --- CONSTANTS ---
const PITCH_COLOR = '#15803d'; 
const PITCH_LINE_COLOR = 'rgba(255,255,255,0.4)';
const BALL_COLOR = '#ffffff';
const BALL_SIZE = 5;
const PLAYER_SIZE = 8;

// Physics Constants
const GAME_DURATION_SEC = 60; // 1 min real time = 90 min game time
const PLAYER_SPEED = 28.0; 
const BALL_FRICTION = 0.975; 
const PLAYER_ACCEL = 5.0; 
const PASS_SPEED = 65.0; 

type GameState = 'PRE_KICKOFF' | 'KICKOFF' | 'PLAYING' | 'GOAL_SCENE';

class GameEngine {
  minute: number = 0;
  homeScore: number = 0;
  awayScore: number = 0;
  
  state: GameState = 'PRE_KICKOFF';
  stateTimer: number = 0;

  ball = { x: 50, y: 50, vx: 0, vy: 0, owner: null as string | null };
  
  players: { 
    id: string; 
    name: string;
    teamId: string; 
    x: number; 
    y: number; 
    vx: number; 
    vy: number; 
    number: number; 
    role: string;
    rating: number; 
    baseX: number;
    baseY: number;
    targetX: number;
    targetY: number;
    noiseX: number;
    noiseY: number;
    distToBall?: number; 
  }[] = [];

  possessionTeamId: string | null = null;
  lastTouchId: string | null = null;
  events: string[] = [];
  
  holdingTimer: number = 0; 
  tackleCooldown: number = 0;
  
  private homeTeam: Team;
  private awayTeam: Team;
  private onScoreUpdate: (h: number, a: number, m: number, ev: string[]) => void;

  constructor(homeTeam: Team, awayTeam: Team, onScoreUpdate: (h: number, a: number, m: number, ev: string[]) => void) {
    this.homeTeam = homeTeam;
    this.awayTeam = awayTeam;
    this.onScoreUpdate = onScoreUpdate;
    this.possessionTeamId = homeTeam.id; 
    this.initPlayers();
    this.setupKickoff(true); 
  }

  initPlayers() {
    const setupTeam = (team: Team, side: 'home' | 'away') => {
      const starters = team.roster.filter(p => !p.offField);
      const formation = FORMATIONS[team.formation || '4-3-3'];

      return starters.map((p, i) => {
        const formPos = formation[i] || { x: 50, y: 50 }; 
        let bx = formPos.x;
        let by = formPos.y;

        if (side === 'away') {
          bx = 100 - bx;
        }

        return {
          id: p.id,
          name: p.name,
          teamId: team.id,
          x: bx, 
          y: by,
          vx: 0,
          vy: 0,
          targetX: bx,
          targetY: by,
          baseX: bx,
          baseY: by,
          noiseX: Math.random() * 100,
          noiseY: Math.random() * 100,
          number: p.number,
          role: p.position,
          rating: p.rating || 75
        };
      });
    };

    this.players = [
      ...setupTeam(this.homeTeam, 'home'),
      ...setupTeam(this.awayTeam, 'away')
    ];
  }

  setupKickoff(isHome: boolean) {
      this.state = 'PRE_KICKOFF';
      this.stateTimer = 1.0;
      this.possessionTeamId = isHome ? this.homeTeam.id : this.awayTeam.id;
      this.ball.owner = null;
      this.ball.vx = 0; this.ball.vy = 0;
      this.ball.x = 50; this.ball.y = 50;
      this.holdingTimer = 0;
      this.tackleCooldown = 0;

      this.players.forEach(p => {
          p.x = p.baseX;
          p.y = p.baseY;
          p.vx = 0;
          p.vy = 0;
      });

      const teamPlayers = this.players.filter(p => p.teamId === this.possessionTeamId);
      const striker = teamPlayers.find(p => p.role === 'FWD') || teamPlayers[teamPlayers.length - 1];
      const support = teamPlayers.find(p => p.role === 'MID') || teamPlayers[Math.floor(teamPlayers.length / 2)];

      if (striker) {
          striker.x = 50;
          striker.y = 50; 
          this.ball.owner = striker.id;
          this.lastTouchId = striker.id;
      }
      if (support && support !== striker) {
          support.x = isHome ? 42 : 58; 
          support.y = 50;
      }
  }

  update(dt: number) {
    if (this.stateTimer > 0) this.stateTimer -= dt;

    if (this.state === 'PRE_KICKOFF') {
        if (this.stateTimer <= 0) this.state = 'KICKOFF';
        return;
    }

    if (this.state === 'KICKOFF') {
        this.performKickoffPass();
        this.state = 'PLAYING';
    }

    if (this.minute >= 90) return;
    
    if (this.state === 'PLAYING') {
        this.minute += dt * (90 / GAME_DURATION_SEC);
        if (this.ball.owner) this.holdingTimer += dt;
        else this.holdingTimer = 0;
        
        if (this.tackleCooldown > 0) this.tackleCooldown -= dt;
    }

    if (this.state === 'GOAL_SCENE') {
        this.ball.x += this.ball.vx * dt;
        this.ball.y += this.ball.vy * dt;
        if (this.ball.x < -5 || this.ball.x > 105 || this.stateTimer <= 0) {
             if (this.stateTimer <= 0) this.confirmGoalLogic();
        }
        return;
    }

    this.updateAI(dt);
    this.updatePhysics(dt);
    this.checkBallInteractions(dt);
  }

  performKickoffPass() {
      const owner = this.players.find(p => p.id === this.ball.owner);
      if (!owner) return;
      const teammate = this.players.find(p => p.teamId === owner.teamId && p.id !== owner.id && Math.abs(p.y - 50) < 10);
      if (teammate) this.executePass(owner, teammate);
  }

  executePass(from: any, to: any) {
      this.ball.owner = null;
      const angle = Math.atan2(to.y - from.y, to.x - from.x);
      this.ball.vx = Math.cos(angle) * PASS_SPEED;
      this.ball.vy = Math.sin(angle) * PASS_SPEED;
      this.lastTouchId = from.id;
      this.holdingTimer = 0;
  }

  updateAI(dt: number) {
    const ballX = this.ball.x;
    const ballY = this.ball.y;

    const defendingTeamId = this.possessionTeamId === this.homeTeam.id ? this.awayTeam.id : this.homeTeam.id;
    const defenders = this.players.filter(p => p.teamId === defendingTeamId && p.role !== 'GK');
    
    defenders.forEach(d => {
        d.distToBall = Math.hypot(d.x - ballX, d.y - ballY);
    });
    defenders.sort((a, b) => (a.distToBall || 999) - (b.distToBall || 999));
    const pressers = defenders.slice(0, 1); 
    const pressingIds = new Set(pressers.map(p => p.id));

    this.players.forEach(p => {
      p.noiseX += dt * 2; 
      p.noiseY += dt * 2;
      const wanderX = Math.sin(p.noiseX) * 1.0; 
      const wanderY = Math.cos(p.noiseY) * 1.0;

      const isHome = p.teamId === this.homeTeam.id;
      const isAttacking = p.teamId === this.possessionTeamId;
      
      if (p.role === 'GK') {
          const goalX = isHome ? 2 : 98;
          let targetY = 50;
          if ((isHome && ballX < 40) || (!isHome && ballX > 60)) {
              targetY = ballY; 
          }
          p.targetX = goalX;
          p.targetY = Math.max(38, Math.min(62, targetY));
          return;
      }

      if (isAttacking) {
          if (this.ball.owner === p.id) {
              const goalX = isHome ? 102 : -2;
              p.targetX = goalX;
              p.targetY = 50 + wanderY * 5; 
          } else {
              let targetX = p.baseX + (ballX - 50) * 0.2; 
              let targetY = p.baseY; 

              const distToBall = Math.hypot(p.x - ballX, p.y - ballY);
              
              if (distToBall < 25) {
                  const candidates = [
                      { x: p.baseX, y: p.baseY },
                      { x: p.baseX + (isHome ? 2 : -2), y: p.baseY - 5 },
                      { x: p.baseX + (isHome ? 2 : -2), y: p.baseY + 5 },
                  ];

                  let bestSpot = { x: targetX, y: targetY };
                  let bestScore = -999;

                  candidates.forEach(cand => {
                      let nearestEnemyDist = 999;
                      this.players.forEach(enemy => {
                          if (enemy.teamId !== p.teamId) {
                              const d = Math.hypot(cand.x - enemy.x, cand.y - enemy.y);
                              if (d < nearestEnemyDist) nearestEnemyDist = d;
                          }
                      });
                      
                      const distToBase = Math.hypot(cand.x - p.baseX, cand.y - p.baseY);
                      const score = nearestEnemyDist * 1.5 - distToBase * 2.0;
                      if (score > bestScore) {
                          bestScore = score;
                          bestSpot = cand;
                      }
                  });
                  targetX = bestSpot.x;
                  targetY = bestSpot.y;
              }

              p.targetX = targetX + wanderX;
              p.targetY = targetY + wanderY;
              p.targetY = Math.max(2, Math.min(98, p.targetY));
              p.targetX = Math.max(1, Math.min(99, p.targetX));
          }
      } else {
          if (pressingIds.has(p.id)) {
              p.targetX = ballX;
              p.targetY = ballY;
          } else {
              const shiftX = (ballX - 50) * 0.1; 
              const shiftY = (ballY - 50) * 0.05; 
              p.targetX = p.baseX + shiftX + wanderX;
              p.targetY = p.baseY + shiftY + wanderY;
              
              const nearestAttacker = this.players.find(att => 
                  att.teamId !== p.teamId && 
                  Math.hypot(att.x - p.x, att.y - p.y) < 8 
              );
              
              if (nearestAttacker) {
                  p.targetX = (p.targetX * 0.7 + nearestAttacker.x * 0.3);
                  p.targetY = (p.targetY * 0.7 + nearestAttacker.y * 0.3);
              }
          }
      }
    });
  }

  updatePhysics(dt: number) {
    this.players.forEach(p => {
       const dx = p.targetX - p.x;
       const dy = p.targetY - p.y;
       const dist = Math.hypot(dx, dy);
       if (dist > 0.5) {
           p.vx += (dx / dist) * PLAYER_ACCEL;
           p.vy += (dy / dist) * PLAYER_ACCEL;
       }
       const speed = Math.hypot(p.vx, p.vy);
       if (speed > PLAYER_SPEED) {
           p.vx = (p.vx / speed) * PLAYER_SPEED;
           p.vy = (p.vy / speed) * PLAYER_SPEED;
       }
       p.x += p.vx * dt;
       p.y += p.vy * dt;
       p.vx *= 0.85; 
       p.vy *= 0.85;
       p.x = Math.max(1, Math.min(99, p.x));
       p.y = Math.max(1, Math.min(99, p.y));
    });

    if (!this.ball.owner) {
        this.ball.x += this.ball.vx * dt;
        this.ball.y += this.ball.vy * dt;
        this.ball.vx *= BALL_FRICTION;
        this.ball.vy *= BALL_FRICTION;
        if (this.ball.y < 0 || this.ball.y > 100) this.ball.vy *= -0.8;
        if ((this.ball.x < 0 || this.ball.x > 100) && this.state === 'PLAYING') {
            const isGoal = this.ball.y > 42 && this.ball.y < 58;
            if (isGoal) {
                this.triggerGoalSequence(this.ball.x > 50);
            } else {
                this.ball.vx *= -0.8;
                this.ball.x = Math.max(0.1, Math.min(99.9, this.ball.x));
            }
        }
    } else {
        const owner = this.players.find(p => p.id === this.ball.owner);
        if (owner) {
            const speed = Math.hypot(owner.vx, owner.vy);
            const dribbleDist = speed > 5.0 ? 2.5 : 1.8; 
            if (speed > 0.5) {
                const nx = owner.vx / speed;
                const ny = owner.vy / speed;
                this.ball.x = owner.x + nx * dribbleDist;
                this.ball.y = owner.y + ny * dribbleDist;
            } else {
                const isHome = owner.teamId === this.homeTeam.id;
                this.ball.x = owner.x + (isHome ? 1.5 : -1.5);
                this.ball.y = owner.y;
            }
            this.ball.vx = owner.vx;
            this.ball.vy = owner.vy;
        }
    }
  }

  checkBallInteractions(dt: number) {
      if (this.state !== 'PLAYING') return;

      if (!this.ball.owner) {
          if (this.tackleCooldown > 0) return;
          let closest = null;
          let minDist = 4.0; 
          for (const p of this.players) {
              const d = Math.hypot(p.x - this.ball.x, p.y - this.ball.y);
              if (d < minDist) {
                  minDist = d;
                  closest = p;
              }
          }
          if (closest) {
              this.ball.owner = closest.id;
              this.possessionTeamId = closest.teamId;
              this.lastTouchId = closest.id;
              this.holdingTimer = 0;
              const isHome = closest.teamId === this.homeTeam.id;
              this.ball.x = closest.x + (isHome ? 1.5 : -1.5);
              this.ball.y = closest.y;
          }
      }

      if (this.ball.owner) {
          const owner = this.players.find(p => p.id === this.ball.owner);
          if (!owner) return;

          if (this.tackleCooldown <= 0) {
              const nearbyEnemies = this.players.filter(p => 
                  p.teamId !== owner.teamId && 
                  Math.hypot(p.x - owner.x, p.y - owner.y) < 3.5
              );
              for (const enemy of nearbyEnemies) {
                  if (Math.random() < 0.05) { 
                       const ratingDiff = (enemy.rating - owner.rating);
                       const winChance = 0.4 + (ratingDiff * 0.01); 
                       if (Math.random() < winChance) {
                           this.ball.owner = enemy.id;
                           this.possessionTeamId = enemy.teamId;
                           this.lastTouchId = enemy.id;
                           this.holdingTimer = 0;
                           this.tackleCooldown = 1.0; 
                           return; 
                       } else {
                           this.tackleCooldown = 0.5; 
                       }
                  }
              }
          }

          const isHome = owner.teamId === this.homeTeam.id;
          const distToGoal = isHome ? (100 - this.ball.x) : this.ball.x;
          const timePressure = this.holdingTimer > 0.2; 
          const forcedMove = this.holdingTimer > 1.5; 

          if (distToGoal < 22 && Math.abs(this.ball.y - 50) < 20) {
               if (Math.random() < 2.5 * dt || forcedMove) {
                   this.shoot(owner, isHome);
                   return;
               }
          } 

          const teammates = this.players.filter(p => p.teamId === owner.teamId && p.id !== owner.id);
          let bestTarget = null;
          let bestScore = -9999;

          teammates.forEach(mate => {
              const dx = mate.x - owner.x;
              const dy = mate.y - owner.y;
              const dist = Math.hypot(dx, dy);
              if (dist < 5 || dist > 60) return; 

              const blocked = this.isPathBlocked(owner.x, owner.y, mate.x, mate.y, owner.teamId);
              if (blocked) return;

              let nearestEnemy = 999;
              this.players.forEach(e => {
                  if (e.teamId !== owner.teamId) {
                      const d = Math.hypot(mate.x - e.x, mate.y - e.y);
                      if (d < nearestEnemy) nearestEnemy = d;
                  }
              });

              const progress = isHome ? (mate.x - owner.x) : (owner.x - mate.x);
              let score = (nearestEnemy * 4.0) + (progress * 1.5);
              if (score > bestScore) {
                          bestScore = score;
                          bestTarget = mate;
              }
          });

          if (bestTarget) {
              if (timePressure || bestScore > 25 || Math.random() < 0.15) {
                  this.executePass(owner, bestTarget);
              }
          } else if (forcedMove) {
              this.ball.owner = null;
              const angle = isHome ? 0 : Math.PI;
              this.ball.vx = Math.cos(angle) * 35;
              this.ball.vy = Math.sin(angle) * 35;
          }
      }
  }

  isPathBlocked(x1: number, y1: number, x2: number, y2: number, teamId: string): boolean {
      const steps = 5;
      for (let i = 1; i < steps; i++) {
          const t = i / steps;
          const px = x1 + (x2 - x1) * t;
          const py = y1 + (y2 - y1) * t;
          const enemyNear = this.players.some(p => p.teamId !== teamId && Math.hypot(p.x - px, p.y - py) < 4);
          if (enemyNear) return true;
      }
      return false;
  }

  shoot(player: any, isHome: boolean) {
      const attackStr = isHome ? this.homeTeam.strength : this.awayTeam.strength;
      const defenseStr = isHome ? this.awayTeam.strength : this.homeTeam.strength;
      const prob = 0.35 + (attackStr - defenseStr) * 0.005;
      this.ball.owner = null;
      const goalX = isHome ? 105 : -5;
      let targetY;
      if (Math.random() < prob) {
          targetY = 44 + Math.random() * 12; 
      } else {
          targetY = Math.random() < 0.5 ? 30 : 70;
      }
      const angle = Math.atan2(targetY - this.ball.y, goalX - this.ball.x);
      const power = 70; 
      this.ball.vx = Math.cos(angle) * power;
      this.ball.vy = Math.sin(angle) * power;
      this.lastTouchId = player.id;
  }

  triggerGoalSequence(isHomeGoal: boolean) {
      this.state = 'GOAL_SCENE';
      this.stateTimer = 1.0; 
  }

  confirmGoalLogic() {
      const isHomeGoal = this.ball.x > 50;
      let scorerText = "Unknown";
      const scorer = this.players.find(p => p.id === this.lastTouchId);
      if (scorer) {
          scorerText = `${scorer.name} (#${scorer.number})`;
      }

      if (isHomeGoal) {
          this.homeScore++;
          this.events.unshift(`${Math.floor(this.minute)}': GOAL! ${scorerText} (${this.homeTeam.shortName})`);
      } else {
          this.awayScore++;
          this.events.unshift(`${Math.floor(this.minute)}': GOAL! ${scorerText} (${this.awayTeam.shortName})`);
      }

      this.onScoreUpdate(this.homeScore, this.awayScore, Math.floor(this.minute), [...this.events]);
      this.setupKickoff(!isHomeGoal); 
  }

  quickSimRemaining() {
      const remainingMinutes = 90 - this.minute;
      if (remainingMinutes <= 0) return;
      
      for (let m = 0; m < remainingMinutes; m++) {
          const homeStr = this.homeTeam.strength;
          const awayStr = this.awayTeam.strength;
          if (Math.random() < 0.015 + ((homeStr - awayStr)*0.0004)) {
              this.homeScore++;
              const p = this.players.filter(p => p.teamId === this.homeTeam.id && p.role !== 'GK')[Math.floor(Math.random()*10)];
              this.events.unshift(`${Math.floor(this.minute + m)}': GOAL! ${p?.name || 'Player'} (${this.homeTeam.shortName}) (Sim)`);
          }
          if (Math.random() < 0.012 + ((awayStr - homeStr)*0.0004)) {
              this.awayScore++;
              const p = this.players.filter(p => p.teamId === this.awayTeam.id && p.role !== 'GK')[Math.floor(Math.random()*10)];
              this.events.unshift(`${Math.floor(this.minute + m)}': GOAL! ${p?.name || 'Player'} (${this.awayTeam.shortName}) (Sim)`);
          }
      }
      this.minute = 90;
      this.onScoreUpdate(this.homeScore, this.awayScore, 90, [...this.events]);
  }
}

const MatchView: React.FC<MatchViewProps> = ({ homeTeam, awayTeam, userTeamId, onMatchComplete, competition = 'La Liga', stage = 'Regular Season' }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const requestRef = useRef<number>(0);
  const previousTimeRef = useRef<number | null>(null);

  const [uiState, setUiState] = useState({ minute: 0, homeScore: 0, awayScore: 0 });
  const [events, setEvents] = useState<string[]>([]);
  
  const isUserHome = userTeamId === homeTeam.id;
  const myRoster = isUserHome ? homeTeam.roster : awayTeam.roster;

  useEffect(() => {
    engineRef.current = new GameEngine(homeTeam, awayTeam, (h, a, m, ev) => {
        setUiState({ minute: m, homeScore: h, awayScore: a });
        setEvents(ev);
    });

    const animate = (time: number) => {
        if (previousTimeRef.current === null) {
            previousTimeRef.current = time;
            requestRef.current = requestAnimationFrame(animate);
            return;
        }

        const deltaTime = (time - previousTimeRef.current) / 1000;
        previousTimeRef.current = time;

        const safeDelta = Math.min(deltaTime, 0.1); 
            
        if (engineRef.current) {
            engineRef.current.update(safeDelta);
            draw(engineRef.current);

            if (Math.floor(engineRef.current.minute) > uiState.minute) {
                setUiState(prev => ({ ...prev, minute: Math.floor(engineRef.current!.minute) }));
            }

            if (engineRef.current.minute >= 90) {
                 cancelAnimationFrame(requestRef.current);
                 setTimeout(() => {
                     onMatchComplete(engineRef.current!.homeScore, engineRef.current!.awayScore);
                 }, 1500);
                 return;
            }
        }
        requestRef.current = requestAnimationFrame(animate);
    };

    requestRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(requestRef.current);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 

  const draw = (engine: GameEngine) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    // Pitch
    ctx.fillStyle = PITCH_COLOR;
    ctx.fillRect(0, 0, w, h);
    
    // Stripes
    ctx.fillStyle = 'rgba(0,0,0,0.05)';
    for (let i = 0; i < w; i += w/10) {
        if ((i / (w/10)) % 2 === 0) ctx.fillRect(i, 0, w/10, h);
    }

    // Lines
    ctx.strokeStyle = PITCH_LINE_COLOR;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(w/2, 0); ctx.lineTo(w/2, h); // Center
    ctx.stroke();
    ctx.beginPath(); ctx.arc(w/2, h/2, h/6, 0, Math.PI * 2); ctx.stroke(); // Circle

    // Goal Boxes
    ctx.strokeRect(0, h/2 - h/5, w/6, h/2.5); 
    ctx.strokeRect(w - w/6, h/2 - h/5, w/6, h/2.5); 

    // Nets
    ctx.fillStyle = 'rgba(255,255,255,0.5)';
    ctx.fillRect(0, h/2 - h/12, 4, h/6);
    ctx.fillRect(w-4, h/2 - h/12, 4, h/6);

    // Players
    engine.players.forEach(p => {
        const px = (p.x / 100) * w;
        const py = (p.y / 100) * h;
        ctx.fillStyle = 'rgba(0,0,0,0.3)';
        ctx.beginPath(); ctx.ellipse(px, py + 2, PLAYER_SIZE, PLAYER_SIZE/2, 0, 0, Math.PI*2); ctx.fill();
        ctx.beginPath(); ctx.arc(px, py, PLAYER_SIZE, 0, Math.PI * 2);
        
        if (p.teamId === homeTeam.id) {
            ctx.fillStyle = homeTeam.primaryColor;
            ctx.strokeStyle = '#fff';
        } else {
            ctx.fillStyle = awayTeam.secondaryColor === '#ffffff' ? awayTeam.primaryColor : awayTeam.secondaryColor;
            ctx.strokeStyle = '#000';
        }
        ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.font = 'bold 8px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(p.number.toString(), px, py);
    });

    const bx = (engine.ball.x / 100) * w;
    const by = (engine.ball.y / 100) * h;
    ctx.beginPath();
    ctx.arc(bx, by, BALL_SIZE, 0, Math.PI * 2);
    ctx.fillStyle = BALL_COLOR;
    ctx.fill();
    ctx.strokeStyle = '#000'; ctx.lineWidth = 1; ctx.stroke();
    
    if (engine.state === 'PRE_KICKOFF' || engine.state === 'KICKOFF') {
        ctx.fillStyle = 'rgba(0,0,0,0.3)';
        ctx.fillRect(0, h/2 - 20, w, 40);
        ctx.fillStyle = '#fff'; ctx.font = 'bold 20px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText("KICK OFF", w/2, h/2);
    }
    if (engine.state === 'GOAL_SCENE') {
        ctx.fillStyle = 'rgba(234,179,8,0.7)'; 
        ctx.fillRect(0, h/2 - 30, w, 60);
        ctx.fillStyle = '#fff'; ctx.font = 'bold 40px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText("GOAL!", w/2, h/2);
    }
  };

  const handleSkip = () => {
    if (engineRef.current) {
        engineRef.current.quickSimRemaining();
        onMatchComplete(engineRef.current.homeScore, engineRef.current.awayScore);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-slate-900 text-white overflow-hidden">
        {/* Scoreboard */}
        <div className="h-16 md:h-20 bg-slate-800 border-b border-slate-700 flex items-center justify-between px-4 md:px-8 shadow-xl z-10 shrink-0">
            <div className="flex items-center gap-2 md:gap-4 w-1/3">
                {homeTeam.logoUrl ? (
                    <img src={homeTeam.logoUrl} alt={homeTeam.name} className="w-8 h-8 md:w-12 md:h-12 object-contain drop-shadow-lg" />
                ) : (
                    <div className="w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center font-bold border-2 border-white/20 text-xs md:text-base" style={{backgroundColor: homeTeam.primaryColor, color: homeTeam.secondaryColor}}>
                        {homeTeam.shortName[0]}
                    </div>
                )}
                <div className="text-xl md:text-3xl font-bold truncate hidden md:block" style={{color: homeTeam.primaryColor}}>{homeTeam.shortName}</div>
                <div className="text-2xl md:text-4xl font-mono font-bold bg-black/20 px-2 md:px-3 py-1 rounded ml-auto">{uiState.homeScore}</div>
            </div>
            
            <div className="flex flex-col items-center justify-center w-1/3">
                 <div className={`text-[10px] md:text-xs uppercase tracking-widest font-bold mb-1 flex items-center gap-1.5 ${competition === 'Champions League' ? 'text-blue-400' : 'text-slate-400'}`}>
                    {competition === 'Champions League' && UCL_LOGO_URL ? <div className="bg-slate-200 rounded-full p-0.5 w-3 h-3 md:w-4 md:h-4 flex items-center justify-center"><img src={UCL_LOGO_URL} className="w-full h-full object-contain" /></div> : null}
                    {competition === 'La Liga' && LIGA_LOGO_URL ? <img src={LIGA_LOGO_URL} className="w-3 h-3 md:w-4 md:h-4 object-contain" /> : null}
                    {competition.replace('Champions League', 'UCL')}
                 </div>
                <div className={`text-2xl md:text-3xl font-mono font-bold ${uiState.minute >= 90 ? 'text-red-500' : 'text-white'}`}>
                    {uiState.minute}'
                </div>
            </div>

            <div className="flex items-center gap-2 md:gap-4 w-1/3 justify-end">
                 <div className="text-2xl md:text-4xl font-mono font-bold bg-black/20 px-2 md:px-3 py-1 rounded mr-auto">{uiState.awayScore}</div>
                 <div className="text-xl md:text-3xl font-bold truncate hidden md:block" style={{color: awayTeam.primaryColor}}>{awayTeam.shortName}</div>
                 {awayTeam.logoUrl ? (
                    <img src={awayTeam.logoUrl} alt={awayTeam.name} className="w-8 h-8 md:w-12 md:h-12 object-contain drop-shadow-lg" />
                ) : (
                    <div className="w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center font-bold border-2 border-white/20 text-xs md:text-base" style={{backgroundColor: awayTeam.primaryColor, color: awayTeam.secondaryColor}}>
                        {awayTeam.shortName[0]}
                    </div>
                )}
            </div>
        </div>

        {/* Game Layout */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            <div className="flex-1 flex flex-col p-2 md:p-4 bg-slate-950 overflow-hidden">
                <div className="flex-1 flex items-center justify-center relative bg-slate-900/50 rounded-xl border border-slate-800 mb-2 md:mb-4 overflow-hidden">
                     <canvas 
                        ref={canvasRef} 
                        width={800} 
                        height={500}
                        className="w-full h-full max-w-full max-h-full object-contain shadow-2xl rounded border-2 md:border-4 border-slate-800 bg-emerald-700"
                    />
                </div>
                <div className="h-32 md:h-48 bg-slate-900 border border-slate-800 rounded-xl flex flex-col overflow-hidden shrink-0">
                    <div className="px-3 py-2 bg-slate-800/80 border-b border-slate-700 flex items-center gap-2">
                        <Activity size={14} className="text-blue-400" />
                        <span className="text-[10px] md:text-xs font-bold uppercase text-slate-300">Match Events</span>
                    </div>
                    <div className="flex-1 overflow-y-auto p-2 md:p-4 space-y-1 md:space-y-2 font-mono text-xs md:text-sm">
                        {events.length === 0 ? (
                            <div className="text-slate-600 italic text-center py-2 md:py-4">Match starting...</div>
                        ) : (
                            events.map((e, i) => (
                                <div key={i} className="flex items-start gap-2 md:gap-3 animate-in fade-in slide-in-from-left-2">
                                    <div className={`w-1.5 h-1.5 md:w-2 md:h-2 mt-1.5 rounded-full shrink-0 ${e.includes('GOAL') ? 'bg-yellow-500' : 'bg-slate-500'}`} />
                                    <div className={`${e.includes('GOAL') ? 'text-yellow-400 font-bold' : 'text-slate-300'}`}>
                                        {e}
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>
            <div className="h-48 md:h-auto md:w-72 bg-slate-800 border-t md:border-t-0 md:border-l border-slate-700 flex flex-col shrink-0">
                <div className="p-3 md:p-4 border-b border-slate-700 bg-slate-900/50">
                    <h3 className="font-bold flex items-center gap-2 text-sm md:text-base">
                        <User size={16} /> Live Squad
                    </h3>
                </div>
                <div className="flex-1 overflow-y-auto p-3 md:p-4 space-y-2">
                    <div className="text-[10px] md:text-xs font-bold text-slate-500 uppercase">On Pitch</div>
                    {myRoster.filter(p => !p.offField).map(player => (
                        <div key={player.id} className="flex items-center justify-between p-2 bg-slate-700/50 rounded">
                            <div className="flex items-center gap-2 md:gap-3">
                                <div className="w-5 h-5 md:w-6 md:h-6 rounded-full bg-slate-900 flex items-center justify-center text-[10px] md:text-xs font-bold text-slate-300">
                                    {player.number}
                                </div>
                                <div className="text-left">
                                    <div className="text-xs md:text-sm font-medium text-slate-200">{player.name}</div>
                                    <div className="text-[9px] md:text-[10px] text-slate-400">{player.position}</div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
                <div className="p-3 md:p-4 border-t border-slate-700">
                    <button 
                        onClick={handleSkip}
                        className="w-full bg-slate-600 hover:bg-slate-500 text-white py-2 md:py-3 rounded-lg font-bold flex items-center justify-center gap-2 transition-colors text-sm md:text-base"
                    >
                         <FastForward size={16} /> Skip to End
                    </button>
                </div>
            </div>
        </div>
    </div>
  );
};

export default MatchView;
